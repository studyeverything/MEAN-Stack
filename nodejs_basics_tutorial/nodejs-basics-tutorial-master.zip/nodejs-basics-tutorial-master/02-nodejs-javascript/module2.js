module.exports = {
    myFunction: function () {
        console.log('Exported!');
    },
    myVariable: 'Exported Variable'
};