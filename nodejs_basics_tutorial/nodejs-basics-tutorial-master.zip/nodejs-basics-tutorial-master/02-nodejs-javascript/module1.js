function myFunction() {
    console.log('Function was called');
}

var myString = 'String!';

module.exports.myFunction = myFunction;
module.exports.myString = myString;