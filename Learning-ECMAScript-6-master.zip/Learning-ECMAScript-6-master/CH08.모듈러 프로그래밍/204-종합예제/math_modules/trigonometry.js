var cos = Math.cos;
var sin = Math.sin;

function getSin(value) {
  return sin(value);
}

function getCos(value) {
  return cos(value);
}

export {getCos, getSin};
