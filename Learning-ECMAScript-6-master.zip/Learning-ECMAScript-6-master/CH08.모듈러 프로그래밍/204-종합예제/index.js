import math from "./math";

console.log(math.trigonometry.getSin(3));
console.log(math.logarithm.getLN2(3));
