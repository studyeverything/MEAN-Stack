import * as logarithm from "./math_modules/logarithm";
import * as trigonometry from "./math_modules/trigonometry";

export default {
  logarithm: logarithm,
  trigonometry: trigonometry
}
