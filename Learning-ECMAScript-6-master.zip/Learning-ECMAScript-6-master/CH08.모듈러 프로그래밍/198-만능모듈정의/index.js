var math = require("./math");

console.log(math.findSum(1, 2));
console.log(math.findSub(1, 2));
