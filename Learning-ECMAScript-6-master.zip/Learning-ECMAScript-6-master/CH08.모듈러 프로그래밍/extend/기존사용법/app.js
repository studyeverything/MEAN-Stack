// 구형 node에서 에러

import {foo, bar} from 'foobar';
console.log(foo());
console.log(bar());
