export function foo() {
  return 'bar';
}
export function bar() {
  return 'foo';
}
