const {foo, bar} = require ( './foobar');
console.log (foo (), bar ());
