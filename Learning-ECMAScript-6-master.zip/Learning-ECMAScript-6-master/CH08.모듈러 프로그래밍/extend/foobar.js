function foo () {
  return 'bar';
}
function bar () {
  return 'foo';
}
module.exports.foo = foo;
module.exports.bar = bar;
