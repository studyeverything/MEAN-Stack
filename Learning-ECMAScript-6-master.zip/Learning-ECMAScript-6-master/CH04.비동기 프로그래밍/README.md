예제를 실행하기 위해서는 node.js가 기본적으로 설치되어있어야 합니다.



1. 해당파일을 실행합니다.

   $ node data_serv.js

2. cross domain 처리를 위해 아래 크롬플러그인을 설치한후 예제를 실행합니다.

https://chrome.google.com/webstore/detail/allow-control-allow-origi/nlfbmbojpeacfghkpbjhddihlkkiljbi?utm_source=chrome-ntp-icon